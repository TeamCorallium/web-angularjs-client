# web-angularjs-client
Corallium Angularjs client
