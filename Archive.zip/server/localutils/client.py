class Client:
    def __init__(self, clientId, connection):
        self.id = clientId
        # self.name = name
        self.connection = connection

clients = []